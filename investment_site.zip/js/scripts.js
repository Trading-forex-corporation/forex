
const timeElement = document.getElementById("time");
if (timeElement) {
    setInterval(() => {
        const date = new Date().toLocaleTimeString("fr-FR", { timeZone: "Africa/Dakar" });
        timeElement.textContent = "Heure: " + date;
    }, 1000);
}

const codes = ["INVEST25C", "INVEST50H", "INVEST75R", "INVEST100E", "INVEST125S", "INVEST150P", "INVEST175O"];
const amounts = ["3000$", "10000$", "25000$", "50000$", "150000$", "500000$", "1500000$"];
let index = 0;

function checkCode() {
    const input = document.getElementById("codeInput").value.trim().toUpperCase();
    const message = document.getElementById("message");
    const progress = document.getElementById("progress-fill");

    if (input === codes[index]) {
        let percent = ((index + 1) / codes.length) * 100;
        progress.style.width = percent + "%";
        message.textContent = "Montant validé : " + amounts[index];
        index++;
        if (index === codes.length) {
            message.textContent = "INVESTISSEMENT TERMINÉ AVEC SUCCÈS. VEUILLEZ CONTACTER MONSIEUR MARK DUBOIS POUR LE RETRAIT";
        }
    } else {
        message.textContent = "Code invalide, veuillez réessayer.";
    }
}
